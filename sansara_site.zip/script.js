document.getElementById("birthForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const day = document.getElementById("day").value;
  const month = document.getElementById("month").value;
  const year = document.getElementById("year").value;

  const resultDiv = document.getElementById("result");
  resultDiv.innerHTML = `<p>Căutăm evenimente pentru <strong>${day}/${month}/${year}</strong>...</p>`;

  // Exemplu simplu - date statice
  if (day == 15 && month == 4) {
    resultDiv.innerHTML += "<p>S-au născut: Leonardo da Vinci, Emma Watson.</p>";
    resultDiv.innerHTML += "<p>Au murit: Abraham Lincoln.</p>";
  } else {
    resultDiv.innerHTML += "<p>(Datele detaliate vor fi adăugate în versiuni viitoare.)</p>";
  }
});